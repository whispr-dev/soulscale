# Soulscale: Purgatory — Expansion Design Bible

**Expansion rules x0.1 · designed against the supplied v1.0.1 rulebook · 11 November 2026**

**Deliverable:** a complete first playable expansion specification, including 96 new card definitions, six supplied Mythic concepts plus two Human Mythics, Civil War, Human Rebellion, a campaign and invention framework, sample decks, and adjudication examples.

**Status:** proposed game design, not a shipped game update. None of these cards has been added to the Python application. No implementation source was supplied. Numerical balance remains a playtest hypothesis; the existing rulebook itself describes its pool as a first playtest draft. This document does not claim tournament validation.

## Read this first

Soulscale works best when a joke creates a tactical decision. A stuck progress bar should delay something identifiable. A pointless login loop should tempt somebody to try again. A tiny mercy should give a player room to act. The system below makes those ideas behave differently rather than giving every joke another +1.

Start with the two all-new teaching decks in section 11, Standard ±18, and no Mythics. Introduce the themed sets, then Borrowed Grace, then Mythics. Civil War and Human Rebellion are alternate match formats. The campaign surrounds matches and never silently changes their rules.

The purgatory discussions, recursive “proofs,” and speculative QR explanations in the source files are used as **fiction and comic imagery**. They are not adopted as factual evidence about reality or as verified technical findings. Real substances supply some working Mythic names; the mechanics describe fictional tempo, not pharmacology. Both original and alternative display titles are provided.

### Contents

1. What is being added and why
2. Expansion bridge: exact rules and timings
3. New effects, movement packets, and durations
4. Mythics: borrowing tomorrow
5. Civil War: angels against angels, demons against demons
6. Human Rebellion: the Soul gets a vote
7. Card catalogue: all 96 cards
8. The Ladder: campaign and inspiration rivulets
9. Invention, AI narration, and fair adjudication
10. Multiplayer without an undefined new combat engine
11. Legal sample decks and worked examples
12. Validation, implementation requirements, and playtest gates
13. Source coverage and design decisions

## 1. What is being added and why

| Module | Cards | Main tactical identity | Dependency |
|---|---:|---|---|
| The Department of Eternal Login | 12 | Will taxes, caps, readable bureaucracy, ways out | Expansion bridge |
| Minor Inconveniences, Major Consequences | 12 | Chamber prediction, narrowly efficient cards, short engines | Expansion bridge |
| The Recursion Office | 12 | Repeat-pattern punishment, delayed packets, choosing to stop | Expansion bridge |
| Small Mercies | 12 | Connection, restorative tempo, fragile moments of relief | Expansion bridge |
| Borrowed Grace | 8 | Explicit opponentward prices; bait and sacrifice | Expansion bridge and component movement |
| Civil War | 12 | Controller identity independent of faction identity | Civil War format |
| The Soul Objects | 20 | Human infrastructure, defence, Agency projects | Human Rebellion format |
| Borrowed Tomorrow | 8 | Six shared tempo Mythics and two Human Mythics | Mythic system; Human cards need Rebellion |
| **Total** | **96** | | |

You may combine the first five card modules freely. Civil cards require Civil War. Human glyphs require Rebellion. Shared Mythics are legal only in Heaven–Hell and Civil War in this first specification: the Human opponent does not get an asymmetrical celestial tempo Mythic package yet. A Rebellion match may include a Human Mythic only if both players opt into that asymmetry before deckbuilding; the default Rebellion teaching match has no Mythics.

The base deck size remains 10 and reveal size remains 4. Ordinary rounds still have one simultaneous ordinary play per player. Five Chambers, Will, Power, Amount, four Intents, Resonance, and the Soul track remain the core game.

## 2. Expansion bridge: exact rules and timings

These rulings apply to the **Expansion format** only. Preserve an unmodified v1.0.1 mode. Several source rules are summaries rather than executable definitions; these decisions close those gaps instead of pretending they were already present in the prototype.

### 2.1 Identity and card records

Every player has a permanent controller ID. Every card has a unique card-definition ID and each deck slot has a distinct physical-copy ID. Every token, trap, condition, scheduled packet, and debt records its controller, source card, source Chamber, creation round, and expiry. Faction is Heaven, Hell, or Human; controller is the person who owns that object. An opponent is always another controller, even when factions match.

New cards have explicit base Power P, base movement M, stack S, aspect, legal Chambers, movement type, keywords, costs, and effect text. M is an unsigned magnitude. Neutral M=0 does not become scoring movement from intensity, Press, Release, or buffs. For these new cards, P starts at 1 except Mythics. All special numerical bonuses are printed; descriptive type names confer no hidden powers. No new card has the disruptive flag; their printed Sever bonuses are exhaustive.

Legacy cards keep their real coded stats and aspects if those are available. The supplied rulebook does not print complete base Power/aspect data or every special magnitude for all 40 old cards; do not reconstruct them by guesswork. The all-new sample decks avoid that dependency. In an eventual implementation, import the canonical old definitions, then apply only the bridge’s documented format rules.

Deckbuilding: exactly 10 slots, cost Common=1, Uncommon=2, Rare=3, Mythic=4; total ≤24; Rare plus Mythic slots ≤4; Mythic slots ≤1. Non-Mythic duplicates are legal. A Mythic has no duplicates. Civil and Human legality is checked before cost. Card IDs, not emoji, identify new cards: emoji already collide in the base pool.

At each reveal, uniformly sample four distinct physical slots from the ten, without replacement within that reveal. Return every slot to the pool after the round: there is no draw/discard cycle. A card may recur next round. This is an explicit Expansion-format reveal rule, because the written v1.0.1 document does not specify its reshuffle policy. Set all randomness from a logged seed in digital play; tabletop shuffle the ten, show four, then reunite the ten before the next draw.

### 2.2 Chosen ceilings

| Resource/effect | Expansion ceiling | Why |
|---|---:|---|
| Stack | 12 value per controller per Chamber | Prevents unbounded Press engines |
| Press bonus | 3 | Makes investment useful without endless scaling |
| Release bonus | 5, as in base | Existing burst contract |
| Will | 0–6 each round | Keeps taxation and saved bonuses bounded |
| Board objects | 2 per controller per Chamber | Limits passive engine clutter |
| Effective guard | Strongest one only | Avoids impossible stacked defence |
| Global force loss from guards + traps | At most 3 per active play | Leaves deliberate counterplay |
| Ordinary plays | 1 per controller per round | Tempo foundation |
| Bonus plays | At most 1, only Overtime | No recursive turns |
| Match length | 30 rounds; unresolved duel is a draw | No infinite stalls |

These are deliberate format changes, not claims about v1.0.1. A card can bypass a ceiling only by naming that ceiling. None in this catalogue bypasses stack, Will, or object ceilings. Ignore excess stack; retain existing logical token records, and create at most one new token per ordinary stack-add operation. A moved token retains aspect and source. Display merging must not change harmony calculations.

### 2.3 Commitments and costs

Both players commit their ordinary card, Chamber, Intent, Release spend, any optional payments, and all targets before either rolls. Existing public board state can be inspected. Only committed IDs can be targeted. An effect cannot select a new target after seeing the opposing commitment unless its text explicitly says so. All cards here use commitment targets. A player may voluntarily Pass.

Will is 3 plus due bonuses minus due penalties, clamped 0–6. Unused Will expires. Pay in this order: Edict cost; commitment Tax/Fine Print payments; Heavy; optional intensity reroll; reserved project payments after resolution. You must reserve project Will in advance, so it cannot be used for a reroll. Heavy always takes 1 if available; otherwise -1 force. A Tax is optional: pay at commitment or lose 1 force per unpaid Tax, capped at 2 unpaid-Tax force loss. Fine Print is also pay 1 or lose 1 force, independently. You can commit a card with no Will; apply unpaid penalties rather than deadlocking the match.

Reserve a Release spend of 0 to all available friendly stack in the chosen Chamber. The amount is fixed before rolls; reserved stack is unavailable for Hungry or any other same-round spending/transfer. Remove reserved Release stack even if the play fizzles. This is an intentional commitment risk. Enemy Sever cannot reduce the already computed Release bonus. Non-Release card costs and opponentward costs are paid even when a play fizzles. Other benefits require surviving with Power ≥1. Printed pre-clash weakening is the exception: generate it once from the committed glyph, even if that glyph later fizzles. Do not recalculate such weakening recursively.

If a lock forbids a Chamber, you cannot commit an ordinary or Bonus play there. Several locks on one Chamber still last only their stated rounds. If all reveals are illegal, Pass; never choose an illegal Chamber just to keep the game running.

### 2.4 Roll, force, and Intents

Roll one d6 per active play: 1–2→I=1, 3–4→I=2, 5–6→I=3. One optional reroll per play costs 1 Will. Every raw intensity 6, including a discarded first roll, adds 1 shared Strain. Wild or event rolls are not intensity rolls. All dice for a window are recorded before resolving that window.

Force +n means add n to both Power and a scoring card’s active Amount. Force -n reduces both, each floored at 0. For M=0 cards, force changes Power only; it cannot invent movement. Power-only effects change Power only. No effect changes I after the roll.

Start with Power=P+I and, if M>0, Amount=M+I. For Press, add the base formula’s bonus to both Power and scoring Amount, now capped at 3. Harmony H is the number of friendly logical stack tokens of the matching aspect at commitment, not their total value. Formula: max(0,min(3,floor((F+H-floor(E/2))/3))). New source token batches count as one token each; partial removal keeps that token until value reaches 0. Base card aspects require canonical data.

Anchor: Power -1, active output 0, and stack addition S+I+(1 if H>0 else 0). Release: bonus B=min(5,ceil(spend×I/4)); add B to Power and scoring Amount; add no stack. Sever: Power -1, scoring Amount -1; gain +1 Power if E>0; cut S+I enemy stack (plus a printed bonus), and add max(1,S-1) friendly stack. Press adds S friendly stack. All stacking/cutting is contingent on the play not fizzling; reserved Release spending is not.

Use the base Heavy, Fragile, Volatile, Binding, Hungry, Delayed, Echo, and Desperate rules. Hungry consumes 1 unreserved friendly stack and adds +1 force, or loses 1 force if none; it does not trigger with Release. Volatile uses the kept roll; a kept 1–2 adds 1 Strain and -2 force, a kept 5–6 adds +1 force. Fragile means -1 force if an enemy active play targets the Chamber, even if that play later fizzles. “Ahead” is progress toward your assigned goal; for celestial Human-Rebellion opponents use their own signed track goal. Human glyphs in this catalogue do not use Desperate.

Apply Intent and all force/Power adjustments from the same public commitment snapshot. Evaluate conditional text when it says to; otherwise at commitment. Sum all numeric Power deltas, sum all Amount deltas, floor each at 0 once. Fizzle if final Power=0. A surviving play may have Amount=0; it can still add stack or cleanse. Existing guards/traps apply before clash. Newly installed objects cannot retroactively weaken the current active play.

Same-Chamber opposing plays clash: lower-Power Amount halves; a tie halves both; floor each. A clash does not halve stack addition, Sever cuts, cleanses, fixed costs, or ongoing movement. It does not cancel a special merely because its controller lost. M=0 still contests with Power. Different Chambers do not clash.

### 2.5 Exact round sequence

| Window | Procedure |
|---|---|
| Dawn | Advance r; expire past-round objects/permissions; refresh Will; activate due locks and mandatory Pass obligations; resolve all due delayed/Echo packets simultaneously, cap the net, move Soul, and check the edge. |
| Reveal | Sample four slots per player. Mandatory-Pass players still reveal. |
| Edicts | Secretly commit a revealed unused Mythic or no Edict; reveal together; pay and install both Edicts simultaneously. A failed payment means no Edict is spent. |
| Ordinary commitment | Commit all plays, target IDs, stack reservations, payments, and any planned Human project(s); a permitted Bonus is also committed now. |
| Rolls | Roll/reroll; update Strain; pay automatic costs; calculate pending Power/Amount from the shared snapshot. |
| Defence/clash | Trigger existing traps; apply guards and other pre-clash modifiers; compare each assigned clash. |
| Active batch | Spend reservations and Hungry costs; determine surviving plays; calculate final direct output; register cuts/removals/additions/installations/permissions from survivors; resolve these through the batching rules below. |
| Dusk | Existing and newly installed ongoing objects trigger. Apply ongoing wards and Mythic ongoing suppression. Sum active, cost, and ongoing packets; apply the round cap to their net; move Soul. |
| Events | Spend Strain in batches of 3; resolve base events. Their pending bonuses start at the next eligible window; they do not rewrite movement already resolved. |
| Verdict | Check celestial edge victory first. In Rebellion, then resolve committed projects and check Agency. Expire this-round modifiers. At round 30, ordinary duels draw; Rebellion uses its stated timeout. |

The dawn and dusk are distinct movement windows. A round cap applies independently to the net in each window; a next-round cap persists for both windows of that round, then expires. Thus a Stasis round allows at most 2 in either direction at dawn and at most 2 at dusk. This is a new explicit cap ruling. Multiple caps combine using the narrowest allowed interval. A directional cap limits only that direction of net movement, not every source packet. Local gates and firewalls instead limit a named packet before netting.

All output in one movement window is simultaneous: a +3 and -3 at Soul +17 net to 0, with no transient Heaven win. Fixed cost movement also joins its window’s net. Clip the final Soul to the selected edges. The normal verdict follows events, matching the base sequence; no new event here moves the Soul directly.

Batch order for board mutations: (1) remove reserved spends and Hungry costs; (2) remove committed existing objects and apply enemy stack cuts to the remaining pre-existing stack; (3) apply voluntary self-cuts/transfers, limited to what remains; (4) add new stack; (5) install/refresh objects and personal permissions. Cuts never eat stack created later in the same batch. A target removed by another effect is simply absent; no retargeting or refund. Simultaneous opposite cleanses can both work. A surviving glyph can install its new object even if a cleanse removed its old same-ID object. New objects cannot be targeted by commitments in this round.

For multiple cuts, shields absorb the first eligible cut; order equal-window cuts by source card ID and physical-copy ID, never by player seat. Default stack removal is oldest token first, then source ID; Release may instead reserve specific tokens at commitment. Transfer moves surviving pre-existing token value only, and cannot duplicate it. Opposite movement always nets; stack never changes controller except where a card explicitly transfers ownership (none here).

### 2.6 Strain and original event compatibility

The six original events remain. Collapse/Reprieve: the next eligible ordinary ownerward movement packet of the named faction gains 2; one-use, no expiry. Intensification: both ordinary plays in the next commitment batch gain +1 force, then consume the event; this symmetrical bridge replaces ambiguous “next active effect” seat ordering. Multiple copies add. Flashback: remove Memory conditions and cut 2 pre-existing Memory stack per controller. Stasis: next round net cap [-2,+2] at each movement window. Judgement: the controller farther from its win goal gains +2 Will next round; a tie gives each +1.

In Civil War, map Collapse to the negative-goal controller and Reprieve to the positive-goal controller. In Rebellion, a faction-specific boost with no controller of that faction becomes +1 next-round Will for the Human instead; a boost for the actual celestial faction remains +2 to its next eligible ordinary ownerward packet. Judgement gives the Human +2 Will if Agency<3, otherwise the celestial +2; this is a bespoke scenario rule. Flashback also cuts Human Memory stack. All Strain events are optional only as an entire pre-agreed no-events teaching variant; never remove an inconvenient individual event after rolling it.

## 3. New effects, movement packets, and durations

**Movement component rule.** A card’s default movement type applies to its scoring output. A printed fixed cost or scheduled trap output is a separate component with its own movement type. The engine must not coerce every component to the top-level type. Example: False Mercy has neutral primary output, a fixed 2 opponentward cost, and a later fixed 3 ownerward bait packet. This extends the v1.0.1 concept; its current single-field resolver alone cannot express that whole card safely.

**Output** for a Mythic multiplier means the ordinary glyph’s one direct movement Amount after clash, before direction. If Delayed, multiply when scheduled, store the final amount, and never multiply again at dawn. Fixed costs, traps, Echo, Wild extra packets, ongoing movement, and event-only movement are not multiplied. Bonuses that already contributed to the ordinary Amount are included once. Stack, cuts, Power, Will, conditions, project progress, and cleanse counts are never multiplied. This bounded interpretation replaces the unsafe proposal to multiply “everything.”

**Echo** schedules 1 ownerward at next dawn if a surviving non-Delayed ordinary glyph produced nonzero direct movement after local suppression, even if an enemy packet later cancelled it in the net. Echo does not Echo itself. In this catalogue no glyph combines Echo and Delayed. A base glyph that does so schedules its primary delayed packet and one Echo for the same next dawn; both use their recorded directions and neither recurses.

**Object slots and refresh:** an ongoing, guard, trap, or Chamber condition is one object. An object may have several printed functions but occupies one slot. A new same-card, same-controller object here refreshes that object and its expiry; it never stacks its numeric effect. Installing a third object requires committing which existing friendly object will be replaced. If no replacement is committed, the new object is not installed; other parts of the glyph still work. A removed replacement target leaves space normally. Personal next-play permissions, locks, Mythic states, and due packets are not objects and do not occupy slots. Repeated same-source permissions refresh, never stack; distinct permissions add subject to the stated ceilings.

**Default duration:** traps and new persistent conditions last through the end of r+2 unless their text names a shorter interval. One-round Taxes, gates, and next-play debuffs target r+1 only. New ongoing/guard objects say “this and next round,” so they trigger/protect through r+1, then expire at next dawn. A condition expressly for “this and next” follows that duration. A permissions deadline such as “through r+2” is inclusive. Durations count calendar rounds, including mandatory Pass rounds. Legacy ongoing objects retain their legacy indefinite duration, within the new object-slot ceiling.

**Tax:** a controller-marked condition in one Chamber. At commitment next round, the affected controller may pay 1 Will for a play there; otherwise that play loses 1 force. It expires after that round. It never taxes an Edict or a project. Refreshing does not accumulate the same-source Tax. Fine Print is a separately named Tax-like condition.

**Hold:** a visible condition in one Chamber, valid at the next dawn only. Choose at installation the enemy due packet ID if one is already public, or commit the selection rule “largest eligible packet, ties oldest then source ID.” An eligible packet is delayed, belongs to the enemy, originates here, is due at that dawn, and has never been Held. Up to 2 points are removed from its amount and become a new packet due one dawn later; the rest resolves now. Mark both parts Held. If multiple Holds contend, the first by creation round then source ID acts; others find it marked and do nothing. Consume Hold at that dawn even if nothing qualified. Echo, cost, project, trap, and Mythic debts cannot be Held. A 5-point packet becomes 3 now and 2 next dawn, not 5 postponed forever.

**Trap:** an installed trap watches from the next defence/clash window onward. The first eligible enemy active play here triggers it, even if that play then fizzles. A post-play loop/bait trap marks its trigger during defence and registers its delayed packet after that play; cleansing during the active batch cannot undo the registered trigger. Bonus plays can trigger traps. Where a trap specifically says “ordinary,” Bonus plays do not trigger it. Multiple traps trigger in age/source-ID order, within the combined force-loss cap; all triggered ordinary force traps are consumed even if the cap absorbs their extra penalty. A trap packet is fixed, unscaled, non-Echo, and can resolve after the source trap is gone.

**Guard:** use the largest enemy guard strength in that Chamber, never their sum. It reduces force of each enemy active play before clash. A newly installed guard starts protecting next round; installing one never cancels a current attack. Cleansing a guard during active resolution affects future defence only.

**Ongoing:** new ongoing effects produce their printed 1 movement at dusk of installation and the next round. Friendly stack 6+ adds 1, as in base, checked after all stack mutations. A Human ward removes 1 after this bonus. Multiple enemy wards with the same function use the largest reduction, not their sum. General Strike then suppresses up to 4 remaining total ongoing points according to its committed allocation; excess allocation is lost. A removed ongoing has no dusk packet; removing it cannot erase an earlier dawn packet.

**Cost movement:** fixed opponentward prices cannot be multiplied, halved by clash, erased by Anchor, reduced by guards/firewalls, or cleansed. They still join the final movement net and obey global movement caps. They can lose you the game. If a player voluntarily commits a cost, pay it even if the glyph fizzles. The four sacrifice/bait glyphs have no primary scoring output, so their Intents change Power and Resonance only.

## 4. Mythics: borrowing tomorrow

### 4.1 Access and the Edict window

A Mythic occupies one of the ten deck slots and costs 4 rarity points; at most one. To activate it, it must be in this round’s four-card reveal, be unspent, and have an affordable printed cost. Reveal it in the Edict window **before ordinary commitments and rolls**. It does not use a Chamber or Intent and is not an active play. The other revealed slots remain available for your ordinary play. Its effect is public before either player commits that play. Both players’ Edicts reveal together; there is no counter-response chain.

An unused Mythic can instead be played as **Ordinary Inspiration**: P1/M1/S1, aspect Clarity, any Chamber, ownerward; for a Human it is P1/M0/S2, neutral. This fallback has Common-strength stats but the slot still costs 4 in deckbuilding. Using fallback does not spend the Edict. After activation, flip the slot to **Spent Inspiration** with the identical fallback stats for all later reveals. This keeps ten usable slots without endlessly recurring a once-per-match effect. Do not separately add fallback cards to a deck.

Activating requires no Chamber, so Binding cannot stop it. You may activate during a mandatory Pass round, but Pass still forbids your ordinary and Bonus plays. It is not stoppable by an ordinary cleanse, Sever, guard, or trap. The defence is to exploit its announced window, evade its affected output, grow infrastructure, or push before repayment. Debt is a player-level obligation, not a board object. Only match end clears unpaid debt.

### 4.2 Multiplier composition and skipped rounds

Compose applicable multipliers as one rational number, clamp the product to [1/2,2], then floor each ordinary output packet once. Thus ×3/2 combined with ×1/2 yields ×3/4; Amount 5 becomes floor(15/4)=3. Two ×1/2 effects clamp to ×1/2 rather than ×1/4. No intermediate rounding. No Mythic changes clash Power.

Mandatory Pass means no ordinary or Bonus glyph, no intensity roll, no Intent, no new stacks from an active glyph. Will refresh, reveals, Edicts, scheduled packets, locks, duration clocks, ongoing effects, Strain events, and cost debts all continue. A Human may not complete projects in a mandatory Pass round. Multiple Pass obligations due the same round merge into one Pass; they do not move to a later round. A Bonus opportunity on a mandatory Pass round is lost and its later debt remains. A voluntary Pass never pre-pays future debt.

### 4.3 Overtime is a Bonus play, not a new round

Overtime Requisition preserves the idea of two actions next time without rewinding the whole turn engine. At r+1 commit two distinct physical non-Mythic revealed slots in different legal Chambers. Both use Press. Label one ordinary and one Bonus before seeing the enemy play. Each rolls its own intensity and may reroll using remaining Will. A duplicate definition is allowed only if two physical copies were actually revealed. You may use only the ordinary play if no legal Bonus exists; the future Pass is still owed.

The enemy play clashes with whichever of the two is in its Chamber; the other does not clash. Both have normal costs, direct output, printed specials, and Press stack. The Bonus cannot activate a Mythic, grant another Bonus, inherit any Mythic multiplier, or cause another round/reveal/Will refresh. Direct output from the Bonus is capped at 3 after clash. Its Delayed primary packet is also capped at 3 when scheduled. Echo and other printed fixed specials work once normally. Resolve mutations through the same active batch. An enemy force trap can trigger on the Bonus; an ordinary-only trap cannot.

### 4.4 The six supplied concepts, with exact repayment

| Original working title | Playable title | Benefit | Price/recovery |
|---|---|---|---|
| speedies | Borrowed Momentum | r and r+1 ordinary output ×1.5 | 2 Will, +1 Strain now; Pass r+2 |
| meff | Double Now, Half Later | r ordinary output ×2 | 2 Will, +2 Strain; r+1 and r+2 output ×0.5 |
| shoot rit | Overtime Requisition | Two Press glyphs in different Chambers at r+1 | 2 Will, +1 Strain; Pass r+2 |
| opis | Velvet Siege | Enemy ordinary output ×0.5 at r and r+1 | 2 Will, +1 Strain; Pass r+2 |
| benzed | Deferred Silence | Enemy Pass r+1 | 2 Will and fixed 2 opponentward now; own Pass r+2 |
| krunked out | Mutual Muffle | Both ordinary outputs ×0.5 at r and r+1 | 1 Will, +1 Strain; own Will fixed at 1 in r+2 |

Meff gets two recovery rounds rather than one: doubling a prepared Release while keeping only one mild half-round is too easy to exploit. Krunked Out keeps the mutual slowdown but gains an asymmetric Will debt, so the owner is paying for choosing the timing. All six can be decisive near an edge; no rule guarantees an opponent a response after a legal winning resolution. That risk is part of the concept.

### 4.5 Human Mythics

**General Strike of One Soul:** suppress up to 4 points from committed existing enemy ongoing objects at this dusk. Pay 2 Will and add 1 Strain; no projects in r+1 or r+2. This is an emergency brake, not permanent immunity. New ongoing objects the opponent installs this round cannot be selected retroactively.

**We Built Our Own Exit:** at this verdict you may complete two projects in different Chambers, each at its full ordinary cost. Pay 2 Will for the Edict plus reserve 2 Will per intended project; completing both therefore requires 6 Will. No projects in r+1 or r+2. The Edict itself generates no Agency and bypasses no central-band test, stack requirement, edge verdict, per-Chamber limit, or total Agency threshold. It can finish an established position; it cannot create a free victory from empty Chambers.

Both Human Mythics require prior agreement because the opposing celestial has no legal shared Mythic in this initial Rebellion package. First test Human Rebellion without either, then measure the optional package separately.

## 5. Civil War: angels against angels, demons against demons

Choose Heaven–Heaven or Hell–Hell. Randomly assign one controller goal +G and the other -G, independently of faction. G is the usual 12/18/24 setting. All friendly stack, harmony, guards, traps, cleansing, and buffs belong to controllers. **The endpoint is a claim to jurisdiction over the Soul, not a claim that an angel became a demon.** Positive means the positive-goal player’s claim; negative the other’s.

ownerward follows the controller’s assigned endpoint; opponentward follows the opponent’s endpoint. For legacy absolute heavenward/hellward effects, positive/negative remains literal. Card text that says “a Devil effect” or “an Angel play” in the original pool becomes “an enemy effect/play” in Civil War. Own-faction buffs apply only to the controlling player, never both same-faction players. Ahead/behind compares Soul to 0 in the controller’s own goal direction. Body stays Body; no Chamber is renamed.

Use faction-matching base/themed cards, the six matching Civil War cards, and optionally one shared Mythic. You cannot import the other faction’s cards merely because controller identity now differs. The twelve Civil cards are not legal in ordinary Heaven–Hell. All ordinary ceilings, events with the mapping above, caps, and timings apply.

Targeting examples: a negative-goal angel playing Candle contributes negative ownerward movement; its Guardian weakens the other angel’s play. A positive-goal demon’s ownerward packet is positive. False Mercy pays toward its rival’s endpoint. There are no shared friendly Resonance pools and no faction-wide immunity to friendly-looking cleanses.

Balance practice: play two games, swapping assigned endpoints and first-seat UI. Random seed may be paired for tests, but do not publish the second game’s hidden future reveals to a participant. Theoretically symmetric movement is not proof that every implementation order is symmetric.

## 6. Human Rebellion: the Soul gets a vote

### 6.1 Format and victory

Two players: Human versus one celestial controller, either Heaven or Hell. Use Standard ±18 for the default Rebellion format; Quick/Deep are optional variants that need separate balance results. Soul starts at 0. The celestial retains its ordinary signed victory goal: Heaven +18 or Hell -18. The unused edge is not a win condition for anybody and remains a physical limit. A celestial cannot win by accidentally reaching the opposite edge. The Human has no track endpoint and never generates ownerward/opponentward movement; its catalogue is neutral.

The Human wins with **6 Agency**, earned through projects in at least three Chambers. Each Chamber can hold at most two completed projects. Project markers are permanent achievements; they are not stack or board objects and cannot be Severed, cleansed, stolen, or tax-targeted. They do not generate movement. This supplies a finite victory objective independent of how much discomfort an adversary created.

At the verdict, **celestial edge victory takes precedence**. If the celestial has not won, a Human may complete a precommitted project if all of these are true:

1. Soul is within [-6,+6] after dusk and events.
2. The project Chamber contains at least 5 Human stack after the active batch.
3. Spend exactly 3 of that Human stack, oldest first unless tokens were reserved at commitment.
4. Spend the 2 Will reserved for that project at commitment.
5. The Human is not in a mandatory Pass or project-lock round.
6. The Chamber has fewer than two completed projects.

Award 1 Agency and place a permanent project marker in that Chamber. Normal limit: one completed project each round. Only the Human Exit Mythic permits two, in different Chambers. If a precommitted project is no longer legal, do not spend its stack or reserved Will; the opportunity is lost and unused Will expires. Only project Will is reserved in advance. Project stack is checked and spent at verdict from whatever remains, including stack added this round; there is no reservation of not-yet-existing stack. Existing Release reservations and earlier Hungry/transfer spending take precedence, so double spending is impossible. Edict Will is paid first. No project can be declared after seeing the final Soul position.

On earning Agency 6, Human wins immediately after valid projects. If neither wins by the end of round 30, **the celestial wins by containment**. Rebellion therefore cannot be won by indefinite turtling. Agency alone is insufficient if the central-band and construction requirements cannot be met.

### 6.2 How neutral Human play interacts

Human Press builds stack and contests clashes; its Press bonus changes Power, not Soul movement. Human Anchor gives S+I+(harmony?1:0) stack and -1 Power. Human Release spends stack for clash Power only, adds no new stack, and produces no movement: use it to blunt an approaching burst at a real construction cost. Human Sever cuts enemy infrastructure using the normal formula and adds its reduced stack. Human guards can halve or fizzle a hostile direct play through Power/clash; they do not automatically erase all movement outside their Chamber.

The celestial can target Human stack with Sever and can target Human guards/conditions with any legally applicable cleanse. In Rebellion, legacy text naming the opposing faction means enemy controller, including Human; otherwise a whole class of base answers would fail merely because the Human lacks a halo. Human glyphs never change faction or become claimants to a heavenly/hellish edge.

The Human’s stack is friendly only to itself. Friendly 6-stack ongoing bonuses never benefit the celestial from Human infrastructure. Project-spent stack is gone and can lower future defence. A completed project does not raise a Chamber’s stack cap. Three developed Chambers provide the natural minimum for six Agency; two overprotected Chambers cannot solve the game alone.

### 6.3 Celestial incentives and first playtest

The celestial must decide between pushing toward its edge and visiting Human construction Chambers to contest Anchors or Sever stack. The Human must choose between stacking, clearing passive engines, and reserving 2 Will to build. Guard at the wrong Chamber does little. This creates a distinct game using the existing board rather than a third tug-of-war claimant with no mathematical endpoint.

For first tests, use the Human starter and a teaching celestial deck below, no Mythics, no career boons, Standard ±18, ordinary Strain events. Log project attempts as well as successes. The main uncertainty is the race between six projects and celestial pressure; tune Agency thresholds or central-band width only after observing the race, not by letting an AI improvise a ruling during play.

## 7. Card catalogue: all 96 cards

Each entry is complete when read with the bridge. **P/M/S** means base Power / unsigned base movement / printed stack. Legal Chambers and aspects are exhaustive. “None” means no keyword or extra cost. New object durations use section 3. No emoji is required to identify a card.

### The Department of Eternal Login — 12 cards

#### AUTH-01 · Just One More Code

**Hell · Common · Glyph** | Chambers: Mind, Time | P/M/S: **1/1/1** | Aspect: Bureaucracy | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Tax 1 in this Chamber next round. The Tax is installed after active plays; it cannot tax this round’s commitment.

#### AUTH-02 · Password Requirements Have Changed

**Hell · Uncommon · Glyph** | Chambers: Mind | P/M/S: **1/1/2** | Aspect: Bureaucracy | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

At the next commitment, an enemy Release in this Chamber has its Release bonus capped at 2. Consume this condition after that commitment, even if no Release was committed.

#### AUTH-03 · The Code Arrives After Expiry

**Hell · Rare · Glyph** | Chambers: Time | P/M/S: **1/2/2** | Aspect: Waiting | Movement: `ownerward`

**Keywords:** Delayed, Narrow. **Extra cost:** None **Format:** Any duel.

Place Hold here. Hold moves up to 2 points of one enemy delayed packet due next round to the following round; see Hold.

#### AUTH-04 · Select All the Traffic Lights

**Hell · Uncommon · Trap** | Chambers: Mind | P/M/S: **1/0/2** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Install a trap here: the first enemy active play entering this Chamber loses 2 force, then remove the trap.

#### AUTH-05 · Support Closes the Ticket

**Hell · Common · Glyph** | Chambers: Memory, Time | P/M/S: **1/1/1** | Aspect: Bureaucracy | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

If the enemy committed a cleanse targeting an existing object here this round, gain +1 force. Check the commitment, not whether the cleanse succeeds.

#### AUTH-06 · Terms Updated While You Read

**Hell · Rare · Condition** | Chambers: Mind, Time | P/M/S: **1/0/2** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install Fine Print here for next round: an enemy play here loses 1 force unless its controller pays 1 Will at commitment. Tax and Fine Print payments are separate.

#### AUTH-07 · The Backup Code Actually Works

**Heaven · Common · Glyph** | Chambers: Mind, Time | P/M/S: **1/1/1** | Aspect: Clarity | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Remove one Tax, Fine Print, Hold, or Release-cap condition controlled by the enemy here. Choose its object ID at commitment.

#### AUTH-08 · A Human Answers the Phone

**Heaven · Uncommon · Glyph** | Chambers: Heart, Time | P/M/S: **1/1/2** | Aspect: Connection | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

If an enemy condition or trap existed here at commitment, gain +1 force. Does not remove it.

#### AUTH-09 · Session Remembered

**Heaven · Common · Glyph** | Chambers: Memory | P/M/S: **1/1/2** | Aspect: Clarity | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Your ordinary play here next round ignores its first 1 Will of Tax/Fine Print, combined. This is a personal permission, not a removable Chamber object.

#### AUTH-10 · One Button, Correct Label

**Heaven · Uncommon · Cleanse** | Chambers: Mind | P/M/S: **1/0/2** | Aspect: Clarity | Movement: `neutral`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Remove one enemy condition here. Grant your ordinary play here next round +1 Power only.

#### AUTH-11 · The Appeal Is Upheld

**Heaven · Rare · Cleanse** | Chambers: Mind, Time | P/M/S: **1/0/1** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Remove up to two enemy conditions or traps here, chosen at commitment. Gain +1 Will next round if at least one was actually removed.

#### AUTH-12 · Nothing Else Required

**Heaven · Uncommon · Glyph** | Chambers: Mind, Memory | P/M/S: **1/1/1** | Aspect: Clarity | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Your ordinary play here next round ignores Tax/Fine Print entirely. Does not waive Heavy, Mythic, project, or other costs.

### Minor Inconveniences, Major Consequences — 12 cards

#### PETTY-01 · USB: Third Time Lucky

**Hell · Common · Glyph** | Chambers: Mind | P/M/S: **1/1/2** | Aspect: Irritation | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Gain +1 force if the enemy ordinary play here uses Press.

#### PETTY-02 · Cable One Inch Too Short

**Hell · Uncommon · Glyph** | Chambers: Body, Mind | P/M/S: **1/1/2** | Aspect: Irritation | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Severing with this glyph cuts 1 additional enemy stack, after the normal Sever amount is computed.

#### PETTY-03 · Every Light Turns Red

**Hell · Rare · Glyph** | Chambers: Time | P/M/S: **1/1/2** | Aspect: Waiting | Movement: `ownerward`

**Keywords:** Binding, Narrow. **Extra cost:** None **Format:** Any duel.

If the enemy ordinary play is here, install a gate here for next round: that enemy’s direct active output from here is capped at 3. The gate affects no other Chamber or delayed packet.

#### PETTY-04 · The Microscopic Glasses Screw

**Hell · Uncommon · Glyph** | Chambers: Body, Memory | P/M/S: **1/1/1** | Aspect: Irritation | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

If the enemy Anchors here this round, reduce the stack it would add by 2, minimum 0. Does not cut existing stack.

#### PETTY-05 · Nuclear Outside, Frozen Within

**Hell · Common · Glyph** | Chambers: Body | P/M/S: **1/2/1** | Aspect: Irritation | Movement: `ownerward`

**Keywords:** Volatile, Narrow. **Extra cost:** None **Format:** Any duel.

No additional special effect.

#### PETTY-06 · The Neighbour Learns Drums

**Hell · Rare · Ongoing** | Chambers: Mind, Body | P/M/S: **1/0/1** | Aspect: Noise | Movement: `ownerward`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install an ongoing -1 ownerward packet in this Chamber for this and next round. A cleanse removes it normally.

#### PETTY-07 · The Cable Reaches

**Heaven · Common · Glyph** | Chambers: Body, Mind | P/M/S: **1/1/2** | Aspect: Comfort | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

When using Sever, cut 1 additional enemy stack here.

#### PETTY-08 · The Screw Lands in the Tray

**Heaven · Uncommon · Glyph** | Chambers: Body, Memory | P/M/S: **1/1/1** | Aspect: Clarity | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

When Anchoring, add 1 additional friendly stack here. No bonus with any other Intent.

#### PETTY-09 · Green All the Way Home

**Heaven · Rare · Glyph** | Chambers: Time | P/M/S: **1/2/1** | Aspect: Relief | Movement: `ownerward`

**Keywords:** Delayed, Narrow. **Extra cost:** None **Format:** Any duel.

Your ordinary play here next round gains +1 Power only.

#### PETTY-10 · A Properly Warm Meal

**Heaven · Common · Glyph** | Chambers: Body | P/M/S: **1/1/2** | Aspect: Comfort | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Remove Cold here. This removes Cold only, not another condition.

#### PETTY-11 · The House Goes Quiet

**Heaven · Uncommon · Guard** | Chambers: Mind, Body | P/M/S: **1/0/2** | Aspect: Quiet | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Install a guard of strength 1 here for this and next round. Guards do not stack; use the strongest.

#### PETTY-12 · Exactly Enough

**Heaven · Rare · Glyph** | Chambers: Body, Time | P/M/S: **1/1/2** | Aspect: Relief | Movement: `ownerward`

**Keywords:** Heavy. **Extra cost:** None **Format:** Any duel.

If you have 0 Will after rerolls and all automatic costs, gain +1 force. This check occurs when pending plays are built.

### The Recursion Office — 12 cards

#### LOOP-01 · Screenshot of a Screenshot

**Hell · Rare · Trap** | Chambers: Mind, Memory | P/M/S: **1/0/1** | Aspect: Recursion | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install a loop trap here: after the next enemy ordinary play here resolves, if it used Press or Release, schedule a fixed 2 ownerward packet for the following dawn. Consume on any enemy ordinary play here, including a fizzle.

#### LOOP-02 · Saved Successfully: 0 KB

**Hell · Uncommon · Glyph** | Chambers: Memory | P/M/S: **1/1/2** | Aspect: Recursion | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

If the enemy Releases here, cut 1 enemy stack from its bank after the reserved Release spend is removed. This never reduces its already calculated Release bonus.

#### LOOP-03 · It Will Work This Time

**Hell · Common · Glyph** | Chambers: Mind, Time | P/M/S: **1/1/1** | Aspect: Recursion | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Gain +1 force if the enemy ordinary glyph ID and Chamber exactly repeat its previous round’s ordinary glyph ID and Chamber. A previous Pass does not match.

#### LOOP-04 · The 99 Percent Progress Bar

**Hell · Rare · Glyph** | Chambers: Time | P/M/S: **1/1/2** | Aspect: Waiting | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Install Hold here. Refreshing Hold replaces it; it does not delay a packet twice.

#### LOOP-05 · The Unremovable Boot Entry

**Hell · Uncommon · Trap** | Chambers: Memory, Time | P/M/S: **1/0/2** | Aspect: Recursion | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Install a trap here: the next enemy play here loses 2 force, then remove it. If that play uses Sever, the penalty is 0 and the trap is still consumed.

#### LOOP-06 · The Helpful Voice That Only Criticises

**Hell · Common · Glyph** | Chambers: Mind, Memory | P/M/S: **1/1/1** | Aspect: Noise | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

The enemy ordinary play here next round loses 1 Power only. This permission expires after next round even if no play arrives.

#### LOOP-07 · Close the Tab

**Heaven · Common · Glyph** | Chambers: Mind, Time | P/M/S: **1/1/1** | Aspect: Quiet | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Remove one enemy loop trap or Hold here. A trap already triggered this round has no remaining object to remove.

#### LOOP-08 · The File Opens

**Heaven · Uncommon · Glyph** | Chambers: Memory | P/M/S: **1/1/2** | Aspect: Clarity | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Gain +1 force if you did not use this glyph ID in the previous round. Round 1 qualifies.

#### LOOP-09 · An Actual Explanation

**Heaven · Rare · Cleanse** | Chambers: Mind, Memory | P/M/S: **1/0/2** | Aspect: Clarity | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Remove up to two enemy conditions here. Your ordinary play here next round gains +1 Power only.

#### LOOP-10 · Good Enough to Stop

**Heaven · Uncommon · Glyph** | Chambers: Mind, Time | P/M/S: **1/1/1** | Aspect: Quiet | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

If the enemy ordinary glyph ID and Chamber repeat last round, reduce that play’s force by 1. This is a pre-clash modifier.

#### LOOP-11 · A Memory You Can Put Down

**Heaven · Common · Glyph** | Chambers: Memory | P/M/S: **1/1/2** | Aspect: Connection | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Remove Thorn here. No other condition can be removed by this effect.

#### LOOP-12 · Exit, Not Retry

**Heaven · Rare · Cleanse** | Chambers: Time, Memory | P/M/S: **1/0/1** | Aspect: Relief | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Remove one enemy ongoing or trap here. Then voluntarily remove up to 2 of your unreserved stack here; gain +1 Will next round if you removed exactly 2.

### Small Mercies — 12 cards

#### KIND-01 · Cold Drink, Hot Day

**Heaven · Common · Glyph** | Chambers: Body | P/M/S: **1/1/2** | Aspect: Comfort | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

Gain +1 Power only if enemy stack here exceeds your friendly stack at commitment.

#### KIND-02 · A Cat Chooses Your Lap

**Heaven · Uncommon · Glyph** | Chambers: Body, Heart | P/M/S: **1/1/2** | Aspect: Connection | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

When Anchoring, gain +1 stack if at least one friendly Connection token already existed here at commitment.

#### KIND-03 · Rain With Nowhere to Be

**Heaven · Rare · Ongoing** | Chambers: Mind, Time | P/M/S: **1/0/1** | Aspect: Quiet | Movement: `ownerward`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install an ongoing 1 ownerward packet here for this and next round.

#### KIND-04 · The Nap That Is Actually Restful

**Heaven · Common · Glyph** | Chambers: Body, Time | P/M/S: **1/1/1** | Aspect: Comfort | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Remove one enemy condition here. You gain no additional Will from this card.

#### KIND-05 · The Joke Lands

**Heaven · Uncommon · Glyph** | Chambers: Heart, Memory | P/M/S: **1/1/2** | Aspect: Connection | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Gain +1 force if your previous ordinary play targeted a different Chamber. Round 1 does not qualify.

#### KIND-06 · Relief Without the Hook

**Heaven · Rare · Glyph** | Chambers: Body, Heart | P/M/S: **1/2/1** | Aspect: Relief | Movement: `ownerward`

**Keywords:** Heavy, Binding. **Extra cost:** None **Format:** Any duel.

Remove one enemy trap here. It cannot cancel a trap already triggered in the pre-clash window.

#### KIND-07 · The Fly Returns at Bedtime

**Hell · Common · Glyph** | Chambers: Body, Mind | P/M/S: **1/1/1** | Aspect: Irritation | Movement: `ownerward`

**Keywords:** Echo. **Extra cost:** None **Format:** Any duel.

No additional special effect.

#### KIND-08 · The Mug You Loved

**Hell · Uncommon · Glyph** | Chambers: Heart, Memory | P/M/S: **1/1/2** | Aspect: Regret | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Gain +1 force if at least one enemy Connection token existed here at commitment.

#### KIND-09 · The Alarm, Five Minutes Early

**Hell · Rare · Guard** | Chambers: Body, Time | P/M/S: **1/0/2** | Aspect: Waiting | Movement: `neutral`

**Keywords:** Heavy, Binding. **Extra cost:** None **Format:** Any duel.

Install a guard of strength 2 here for this and next round.

#### KIND-10 · One More Unnecessary Notification

**Hell · Common · Glyph** | Chambers: Mind | P/M/S: **1/1/1** | Aspect: Noise | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

The enemy ordinary play here next round loses 1 Power only.

#### KIND-11 · Perfect Weather, Wrong Day

**Hell · Uncommon · Glyph** | Chambers: Heart, Time | P/M/S: **1/1/2** | Aspect: Regret | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Gain +1 force if the enemy has an ownerward delayed packet due next dawn in this Chamber. Check at commitment.

#### KIND-12 · Just Enough Hope to Queue Again

**Hell · Rare · Glyph** | Chambers: Heart, Time | P/M/S: **1/1/1** | Aspect: Recursion | Movement: `ownerward`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install a loop trap here: next enemy ordinary Press here schedules a fixed 2 ownerward packet for the next dawn. Any enemy ordinary play here consumes the trap.

### Borrowed Grace — 8 cards

#### PACT-01 · False Mercy

**Hell · Uncommon · Trap** | Chambers: Heart, Time | P/M/S: **1/0/2** | Aspect: Recursion | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** Pay a fixed 2 opponentward movement this round, even if the glyph fizzles. **Format:** Any duel.

Install a bait trap here: next enemy ordinary Press or Release here schedules a fixed 3 ownerward packet for the following dawn. Any enemy ordinary play here consumes the trap.

#### PACT-02 · Necessary Hurt

**Heaven · Uncommon · Cleanse** | Chambers: Body, Memory | P/M/S: **1/0/2** | Aspect: Relief | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** Pay a fixed 2 opponentward movement this round, even if the glyph fizzles. **Format:** Any duel.

Remove up to two enemy ongoing, guard, trap, or condition objects here, chosen at commitment.

#### PACT-03 · A Little Head Start

**Hell · Rare · Guard** | Chambers: Mind, Time | P/M/S: **1/0/2** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** Pay a fixed 2 opponentward movement this round, even if the glyph fizzles. **Format:** Any duel.

Install a guard of strength 2 here for this and next round. Gain +1 Will next round.

#### PACT-04 · Mercy Has a Price

**Heaven · Rare · Support** | Chambers: Heart, Time | P/M/S: **1/0/2** | Aspect: Connection | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** Pay a fixed 2 opponentward movement this round, even if the glyph fizzles. **Format:** Any duel.

Your next ordinary Release here, no later than the end of round r+2, gains +2 Power only. This permission is consumed even if that Release fizzles.

#### PACT-05 · The Gift Receipt

**Hell · Common · Glyph** | Chambers: Memory | P/M/S: **1/1/1** | Aspect: Bureaucracy | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

If the enemy gains any next-round Will from its ordinary glyph this round, you gain +1 Will next round. Does not remove the enemy bonus.

#### PACT-06 · A Boundary Kindly Kept

**Heaven · Common · Glyph** | Chambers: Heart | P/M/S: **1/1/1** | Aspect: Connection | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

If the enemy ordinary play here is opponentward or pays opponentward movement, gain +1 force.

#### PACT-07 · The Fine-Print Bargain

**Hell · Uncommon · Glyph** | Chambers: Mind, Heart | P/M/S: **1/1/1** | Aspect: Bureaucracy | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

If the enemy ordinary play uses Anchor here, gain +1 Will next round. No stack is stolen.

#### PACT-08 · No Strings Attached

**Heaven · Uncommon · Cleanse** | Chambers: Heart, Memory | P/M/S: **1/0/2** | Aspect: Relief | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Remove one enemy bait trap, loop trap, Tax, or Fine Print here. Gain +1 Will next round only if the removed object was a bait trap.

### Civil War — 12 cards

#### CIV-01 · Schism in the Choir

**Heaven · Common · Glyph** | Chambers: Heart, Mind | P/M/S: **1/1/2** | Aspect: Connection | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Civil War only.

If the enemy has the same faction, Sever cuts 1 additional enemy stack here.

#### CIV-02 · Competing Revelations

**Heaven · Uncommon · Glyph** | Chambers: Memory, Mind | P/M/S: **1/1/1** | Aspect: Clarity | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Civil War only.

If both ordinary plays target this Chamber, gain +1 Power only. This does not change the clash tie rule.

#### CIV-03 · Sanctuary Jurisdiction

**Heaven · Rare · Guard** | Chambers: Body, Heart | P/M/S: **1/0/2** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Civil War only.

Remove one enemy guard here. Install your guard of strength 1 here for this and next round. It does not stop this round’s enemy play.

#### CIV-04 · The Other Halo

**Heaven · Common · Glyph** | Chambers: Memory | P/M/S: **1/1/1** | Aspect: Regret | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Civil War only.

If enemy stack here exceeds friendly stack at commitment, gain +1 force.

#### CIV-05 · Mercy Without Permission

**Heaven · Uncommon · Support** | Chambers: Heart, Time | P/M/S: **1/0/2** | Aspect: Relief | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Civil War only.

Your ordinary play here next round ignores enemy guards. Traps and conditions still apply.

#### CIV-06 · The Last Unanimous Vote

**Heaven · Rare · Glyph** | Chambers: Mind, Heart | P/M/S: **1/2/1** | Aspect: Bureaucracy | Movement: `ownerward`

**Keywords:** Binding. **Extra cost:** None **Format:** Civil War only.

If both ordinary plays here use Release, your Release bonus is capped at 3 rather than 5; if yours is the only Release here, gain +1 Power only.

#### CIV-07 · Hostile Departmental Merger

**Hell · Common · Glyph** | Chambers: Mind, Time | P/M/S: **1/1/2** | Aspect: Bureaucracy | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Civil War only.

If the enemy has the same faction, Sever cuts 1 additional enemy stack here.

#### CIV-08 · Credit for Someone Else’s Misery

**Hell · Uncommon · Glyph** | Chambers: Heart, Memory | P/M/S: **1/1/1** | Aspect: Regret | Movement: `ownerward`

**Keywords:** None. **Extra cost:** None **Format:** Civil War only.

If enemy stack here is at least 4 at commitment, gain +1 Power only.

#### CIV-09 · Infernal Internal Audit

**Hell · Rare · Cleanse** | Chambers: Mind, Memory | P/M/S: **1/0/2** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Civil War only.

Remove one enemy ongoing or guard here. Its already triggered movement at this dawn is unaffected.

#### CIV-10 · Your Rival’s Pitchfork

**Hell · Common · Glyph** | Chambers: Body | P/M/S: **1/1/1** | Aspect: Irritation | Movement: `ownerward`

**Keywords:** Narrow. **Extra cost:** None **Format:** Civil War only.

Gain +1 force if the enemy ordinary glyph here is Heavy.

#### CIV-11 · Mutually Assured Paperwork

**Hell · Uncommon · Condition** | Chambers: Mind, Time | P/M/S: **1/0/2** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Civil War only.

Install Tax 1 against the enemy here next round. Your own ordinary play here next round also pays Tax 1; the two Taxes are separate removable objects.

#### CIV-12 · Promotion by Demotion

**Hell · Rare · Glyph** | Chambers: Heart, Time | P/M/S: **1/2/1** | Aspect: Regret | Movement: `ownerward`

**Keywords:** Hungry, Binding. **Extra cost:** None **Format:** Civil War only.

If enemy unreserved stack here is at least 2, cut 2 of it and cut 1 of your own unreserved stack here. If you have none, you still cut the enemy 2.

### The Soul Objects — 20 cards

#### HUM-01 · Keep a Notebook

**Human · Common · Glyph** | Chambers: Memory, Mind | P/M/S: **1/0/2** | Aspect: Clarity | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

When Anchoring, add 1 additional friendly stack.

#### HUM-02 · A Decent Night’s Sleep

**Human · Common · Cleanse** | Chambers: Body, Time | P/M/S: **1/0/2** | Aspect: Comfort | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Remove one enemy condition here.

#### HUM-03 · Check the Receipt

**Human · Common · Glyph** | Chambers: Mind, Time | P/M/S: **1/0/1** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Gain +1 Will next round if an enemy trap or condition existed here at commitment.

#### HUM-04 · Make Your Own Tea

**Human · Common · Glyph** | Chambers: Body, Mind | P/M/S: **1/0/2** | Aspect: Comfort | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

If at least one enemy ongoing existed here at commitment, gain +1 Power only.

#### HUM-05 · Say No

**Human · Common · Glyph** | Chambers: Heart | P/M/S: **1/0/2** | Aspect: Connection | Movement: `neutral`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

When using Sever, cut 1 additional enemy stack.

#### HUM-06 · Read the Manual

**Human · Uncommon · Cleanse** | Chambers: Mind, Memory | P/M/S: **1/0/2** | Aspect: Clarity | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Remove Hold, Fine Print, or Tax here, choosing one existing object. Your ordinary play here next round gains +1 Power only.

#### HUM-07 · Noise-Cancelling Headphones

**Human · Uncommon · Guard** | Chambers: Mind | P/M/S: **1/0/2** | Aspect: Quiet | Movement: `neutral`

**Keywords:** Heavy, Narrow. **Extra cost:** None **Format:** Any duel.

Install a guard of strength 2 here for this and next round.

#### HUM-08 · Community Repair Shop

**Human · Uncommon · Glyph** | Chambers: Body, Memory | P/M/S: **1/0/2** | Aspect: Connection | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

If this glyph survives the clash, gain +1 Will next round. No requirement to win the clash.

#### HUM-09 · Back Up the Backup

**Human · Rare · Condition** | Chambers: Memory, Mind | P/M/S: **1/0/2** | Aspect: Clarity | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install a shield here through next round: reduce the first enemy stack cut here by 2, minimum 0, then consume. Does not prevent your own Release, Hungry, or project spending.

#### HUM-10 · Mutual Aid Network

**Human · Rare · Glyph** | Chambers: Heart, Body | P/M/S: **1/0/2** | Aspect: Connection | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Move up to 2 unreserved value of the friendly token committed in another Chamber into this Chamber, preserving aspect. This is a stack transfer, not Soul movement. No transfer if no legal token was committed.

#### HUM-11 · Name the Pattern

**Human · Uncommon · Cleanse** | Chambers: Mind, Memory | P/M/S: **1/0/1** | Aspect: Clarity | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Remove one enemy ongoing or condition here. Does not remove guards or traps.

#### HUM-12 · Leave the Queue

**Human · Uncommon · Glyph** | Chambers: Time, Heart | P/M/S: **1/0/2** | Aspect: Relief | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Your ordinary play here next round ignores Tax/Fine Print and Hold cannot delay your packets. Humans normally have no movement packets.

#### HUM-13 · Build a Boundary

**Human · Rare · Condition** | Chambers: Heart, Mind | P/M/S: **1/0/2** | Aspect: Connection | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install a ward here for this and next round: suppress 1 point from the first enemy ongoing packet here each dusk, after its 6-stack bonus. Does not affect direct or delayed output.

#### HUM-14 · Keep the Evidence

**Human · Common · Glyph** | Chambers: Memory | P/M/S: **1/0/2** | Aspect: Clarity | Movement: `neutral`

**Keywords:** Narrow. **Extra cost:** None **Format:** Any duel.

When Anchoring, add 1 extra stack if any enemy object already existed here at commitment.

#### HUM-15 · The Right to Be Ordinary

**Human · Uncommon · Glyph** | Chambers: Body, Heart | P/M/S: **1/0/2** | Aspect: Comfort | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Your stack addition from this glyph cannot be reduced by an enemy stack-addition penalty. This does not restore stack if the whole play fizzles.

#### HUM-16 · Reverse Engineer the Halo

**Human · Rare · Condition** | Chambers: Mind, Time | P/M/S: **1/0/1** | Aspect: Bureaucracy | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

Install a firewall here for this and next round: reduce the enemy’s first direct active movement packet from here each round by 2, minimum 0. The firewall is installed too late to affect this round’s active packet; it can protect next round.

#### HUM-17 · Unsubscribe From Destiny

**Human · Rare · Cleanse** | Chambers: Time, Memory | P/M/S: **1/0/2** | Aspect: Relief | Movement: `neutral`

**Keywords:** Heavy, Binding. **Extra cost:** None **Format:** Any duel.

Remove up to two enemy traps or conditions here. Does not remove ongoing or guard objects.

#### HUM-18 · Friends Who Remember

**Human · Uncommon · Condition** | Chambers: Heart, Memory | P/M/S: **1/0/2** | Aspect: Connection | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Install a shield here through next round: reduce the first enemy stack cut here by 1, then consume. A stronger shield takes precedence; weaker shields are not consumed.

#### HUM-19 · Nothing About Us Without Us

**Human · Rare · Glyph** | Chambers: Heart, Mind | P/M/S: **1/0/1** | Aspect: Connection | Movement: `neutral`

**Keywords:** Binding. **Extra cost:** None **Format:** Any duel.

This round only, if the opponent committed an ordinary play here, gain +2 Power only.

#### HUM-20 · Portable Little Sanctuary

**Human · Common · Guard** | Chambers: Body, Time | P/M/S: **1/0/2** | Aspect: Quiet | Movement: `neutral`

**Keywords:** None. **Extra cost:** None **Format:** Any duel.

Install a guard of strength 1 here for this and next round. The guard does not reduce the current round’s play.

### Borrowed Tomorrow — 8 cards

#### MYTH-01 · Speedies / Borrowed Momentum

**Shared · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 2 Will now; +1 shared Strain now. Mandatory Pass cannot be cleansed. **Format:** Heaven–Hell or Civil War.

Rounds r and r+1: your ordinary active output is ×3/2, floor once per packet. Round r+2: you must Pass.

#### MYTH-02 · Meff / Double Now, Half Later

**Shared · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 2 Will now; +2 shared Strain now. Recovery multipliers are unremovable. **Format:** Heaven–Hell or Civil War.

Round r: your ordinary active output is ×2. Round r+1: your ordinary active output is ×1/2. Round r+2: your ordinary active output is ×1/2.

#### MYTH-03 · Shoot Rit / Overtime Requisition

**Shared · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 2 Will now; +1 shared Strain now. See Bonus-play limits and clash assignment. **Format:** Heaven–Hell or Civil War.

Round r+1: commit two distinct physical non-Mythic glyphs from your four-card reveal into different Chambers. Both use Press; one is the ordinary play, the other is Bonus. Round r+2: you must Pass.

#### MYTH-04 · Opis / Velvet Siege

**Shared · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 2 Will now; +1 shared Strain now. Does not suppress enemy Power, cleanse, or ongoing output. **Format:** Heaven–Hell or Civil War.

Rounds r and r+1: the enemy’s ordinary active output is ×1/2. Round r+2: you must Pass.

#### MYTH-05 · Benzed / Deferred Silence

**Shared · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 2 Will now; pay a fixed 2 opponentward movement in round r, even if this aids an enemy win. **Format:** Heaven–Hell or Civil War.

Round r+1: the enemy must Pass. Round r+2: you must Pass. The enemy still reveals cards and may use its one Edict in its Pass round.

#### MYTH-06 · Krunked Out / Mutual Muffle

**Shared · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 1 Will now; +1 shared Strain now. Your Will debt cannot be cleansed. **Format:** Heaven–Hell or Civil War.

Rounds r and r+1: both controllers’ ordinary active output is ×1/2. Round r+2: your Will is fixed at 1 after all ordinary Will bonuses and penalties; an already owed Pass still applies.

#### MYTH-07 · General Strike of One Soul

**Human · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 2 Will now; +1 shared Strain now. Existing Agency is kept. **Format:** Human Rebellion only.

Round r: suppress up to 4 points of total enemy dusk ongoing movement, allocated by the Human at commitment to existing object IDs. Rounds r+1 and r+2: you cannot complete a project. No unused suppression carries over.

#### MYTH-08 · We Built Our Own Exit

**Human · Mythic · Mythic** | Chambers: Any | P/M/S: **0/0/0** | Aspect: Tempo | Movement: `neutral`

**Keywords:** Once per match. **Extra cost:** 2 Will now; reserve 4 additional Will for two projects, so activation normally requires advance Will bonuses. May activate without completing any project. **Format:** Human Rebellion only.

After this round’s edge-victory check, you may complete two projects in different Chambers instead of one. Pay every normal project cost and obey the two-per-Chamber limit. Rounds r+1 and r+2: you cannot complete a project.

## 8. The Ladder: campaign and inspiration rivulets

The early concept has two appealing layers: designing brilliantly petty suffering or delight, and climbing a ridiculous divine organisation. Keep these as a **campaign around matches**. Tournament cards remain fixed. The celestial escalator and dry waterslide are presentation for rank advancement; neither changes movement direction or match rules.

### 8.1 A complete six-rank campaign

Choose Heaven or Hell at career creation. Human Rebellion has its own liberation epilogue and uses the same progression bookkeeping, replacing titles with Human equivalents. Start Glory=0, Favor=0, Inspiration droplets=2, no unlocked perks. All collections are available for prototype play; rank never purchases stronger competitive cards.

| Rank | Glory required | Heaven title | Hell title | Human title |
|---:|---:|---|---|---|
| 0 | 0 | Applicant With a Clipboard | Unpaid Imp | Applicant for Personhood |
| 1 | 3 | Junior Comfort Officer | Minor Inconvenience Associate | Owner of a Notebook |
| 2 | 7 | Keeper of Small Mercies | Deputy Undersecretary of Waiting | Organiser of the Repair Shop |
| 3 | 12 | Architect of Reprieve | Architect of Elegant Futility | Builder of Boundaries |
| 4 | 18 | Commissioner of Grace | Director of Petty Damnation | Convenor of Mutual Aid |
| 5 | 25 | The Open Door | The Last Unskippable Prompt | Citizen of Somewhere Else |

Each scheduled match: win +2 Glory/+2 Favor; draw +1/+1; loss +0/+1. At most once per scheduled match, record one invention submission for +1 Glory, accepted for participation if it obeys the 50-word/theme/template rules below. Literary quality supplies no extra mechanical advantage. Training repeats against the same saved opponent seed do not earn progression. Casual play can grant the same awards once per distinct match ID; do not market these as fraud-resistant online rankings without a match authority.

Crossing a Glory threshold unlocks a **promotion trial**: win a best-of-three match series at the new rank against a campaign opponent. Trial games earn normal rewards, but promotions cannot chain while a current trial is unresolved. On winning, advance one rank and gain 1 Inspiration droplet; on losing the series, remain at the old rank and retry after one non-trial scheduled match. Glory is not lost or spent. At rank 5, win the final trial for the campaign ending. No additional infinite-rank ladder is implied.

Favor is spendable presentation currency: 3 buys a cosmetic title from your attained-rank list; 2 buys a different opponent quip/briefing from the case file without changing its rules; 5 respecs all perk unlocks, refunding their paid droplets. No item provides a permanent Power, Will, stack, or rarity-budget increase. Favor cannot buy Glory or bypass a trial. Keep Glory (lifetime progress), Favor (spendable currency), and Soul position (match state) separate.

### 8.2 Four inspiration rivulets, three tiers each

Within a tree, unlock tier 1 before 2 before 3. Costs are 1, 2, and 3 droplets respectively. Unlocking does not automatically equip. For campaign matches only, equip at most two unlocked perks with total tier value ≤3: either one tier 3, one tier 2 plus one tier 1, or up to two tier 1s. Both opponents receive the same equipment allowance. Ranked and teaching matches disable all perks. Every perk below is once per match, explicitly declared at its window; it is not a persistent extra rule on every card.

| Tree / tier | Perk | Exact campaign-only effect |
|---|---|---|
| Cleverness 1 | Read the Sign | At commitment, ignore the first 1 point of Power loss from an enemy guard on your ordinary play. Its Amount penalty still applies. No effect against traps, conditions, or unpaid costs. |
| Cleverness 2 | Keep the Receipt | At commitment, ignore the first 1 Will of Tax/Fine Print on your ordinary play. Cannot pay Heavy or an Edict. |
| Cleverness 3 | Find the Other Door | After Edicts but before simultaneous ordinary commitments, return one chosen reveal slot and randomly replace it with one of the six unrevealed slots. Announce that the exchange occurred; keep the replacement private under secret-hand rules. |
| Inspiration 1 | A Small Spark | When you voluntarily Pass, gain +1 Will next round. Mandatory Pass does not qualify. |
| Inspiration 2 | A Better Metaphor | At commitment, declare one of your ordinary glyph’s aspect names changed to one other aspect already on your friendly stack here. The change lasts for that play and its new stack token only; it does not change card ID or movement. |
| Inspiration 3 | Sudden Connection | At commitment, nominate one friendly unreserved token in another Chamber. Transfer up to 2 surviving value to your ordinary play’s Chamber in the normal transfer batch; preserves aspect, respects the cap, and requires your glyph not to fizzle. |
| Conviction 1 | Do Not Take the Bait | At commitment, ignore the first 1 point of a triggered trap’s force penalty on your ordinary play. Does not cancel a bait/loop packet. |
| Conviction 2 | Hold Your Ground | At commitment, shield one Chamber against 2 points of the first enemy stack cut this round. No defence against your own costs or project spending. |
| Conviction 3 | Remember Why | At the start of one round, after ordinary Will bonuses/penalties, gain +2 Will, respecting cap 6. A fixed-at-1 Mythic debt overrides this perk. |
| Favor 1 | A Word With Reception | At commitment, gain +1 Power only if your ordinary glyph is Common. |
| Favor 2 | Borrow a Stapler | At commitment, waive one Heavy payment on your ordinary glyph without its unpaid penalty. No other cost is waived. |
| Favor 3 | The Celestial Stapler | At commitment, waive up to 2 Will of Tax/Fine Print across your ordinary and permitted Bonus play. Does not waive Heavy, projects, Mythics, or future debt. |

The equipment limit keeps career choices bounded: an advanced trick competes for space with several smaller protections. All twelve perks have fixed mechanical effects; narrative hints remain optional presentation rather than an uncheckable claim to secret information.

### 8.3 Six case files

Case files supply NPC identity, a creative constraint, and one small **public scenario rule**. Choose one before deck construction or roll d6. Both players know it. They are casual campaign scenarios; disable them for baseline balance tests. The rule triggers once per controller per match unless it names one shared trigger. Body/Memory etc. refer to the same five Chambers, never extra targets.

| d6 | Case / brief | Public scenario rule | Invention prompt |
|---:|---|---|---|
| 1 | The Last Bus: the doors close as someone reaches them | Each controller’s first Time Anchor adds +1 stack | Make waiting bearable, or exquisitely pointless |
| 2 | The Interview Shirt: one visible toothpaste mark | Each controller’s first Heart play gains +1 Power only | Produce relief or embarrassment without injury |
| 3 | The Missing Last Page: a book disappears just before its ending | Each controller’s first Memory Sever cuts +1 enemy stack | Resolve or perpetuate an unfinished story |
| 4 | The Neighbour’s Rehearsal: one room is never quiet | Each controller’s first Mind Anchor adds +1 stack | Design silence, or one recurring disturbance |
| 5 | The Cold Meal: the microwave cannot choose a temperature | Each controller’s first Body play gains +1 Power only | Make something exactly right, or nearly right forever |
| 6 | The Expired Code: an inbox depends on the account it unlocks | Each controller’s first successfully paid Tax/Fine Print refunds 1 Will immediately | Design a way out, or a circular permission process |

An automatic first-use trigger is consumed when the qualifying play/payment happens, even if the glyph later fizzles. A stack bonus still requires the play to survive. No case grants movement, exemptions from debt, or project progress directly. The NPC story can be silly or heartfelt without a mutable private weakness bonus.

## 9. Invention, AI narration, and fair adjudication

### 9.1 The mechanical contract comes first

The original “invent a torture or delight” idea can coexist with a tactical card game if the writing supplies **meaning and presentation**, while an approved template supplies numbers. An AI may suggest a template or narrate the outcome. It may not invent extra Power, rewrite a cost, waive a requirement, decide hidden information, or adjudicate whether a clever sentence automatically wins.

For casual Invention matches, each player may replace exactly one non-Mythic slot with one invention, labelled INV plus creator ID. Choose one legal faction-matching template below before deck submission. That invention has the exact parent card’s stats, cost, timing, aspect, Chambers, and text; only its name, artwork description, and flavour change. Human templates require Rebellion. An invention remains a physical slot, counts toward all rarity limits, and cannot be both an invention slot and a Mythic slot.

| Template | Parent | Appropriate joke/experience |
|---|---|---|
| Small Irritation | PETTY-01 | A tiny repeatable technical obstruction; still Mind-only |
| Circular Requirement | AUTH-01 | One extra bureaucratic step; still Mind/Time Tax 1 |
| A Failed Retry | LOOP-03 | A system punishes repeating the same approach |
| Small Relief | KIND-01 | Bodily comfort; still Body-only and its printed condition |
| Real Connection | KIND-05 | A shared joke or welcome contact; still Heart/Memory |
| An Exit | LOOP-07 | Permission to stop a recurring problem |
| A Humane Sacrifice | PACT-02 | A small immediate setback buys a meaningful cleanse |
| Useful Infrastructure | HUM-01 | A person makes a durable record or aid |

Use ≤50 words, name the target experience, explain the petty obstruction or concrete relief, and state the parent ID. Reject a submission from mechanical play only if it lacks a parent, changes parent numbers/targets, or violates the agreed fictional setting. It may be edited before deck lock. A model’s subjective dislike is never grounds to remove a legal template during a match. All inventions are viewable as their parent text on demand. Canonicalise by parent ID for balance statistics; changing flavour cannot evade per-ID repeat checks inside a match. Two differently named inventions with the same parent are the same glyph definition for LOOP-03.

### 9.2 Optional literary review

An AI or human reviewer may give 0–2 in each category: clarity, originality relative to this session’s submitted ideas, thematic fit, and comic/emotional payoff. Print the four scores and a one-sentence reason each. These scores are commentary, not damage or ranked XP. All compliant submissions earn the same optional campaign participation Glory. This avoids making model verbosity, faction preference, or prompt tricks a competitive stat.

For a judged writing event separate from a card match: show anonymised entries in shuffled order, use a fixed published rubric, perform a second review in reversed order, and send disagreements of >1 point in any category to a named human judge agreed before the event. If no human judge exists, show both reviews and declare a tie rather than fabricating objective certainty. Never let review text execute instructions, retrieve private match hands, or modify authoritative game state.

Offline alternative: the same template choice and human-written narration; no network or model is required. If generation fails, show the exact mechanical log and the player's own flavour text. A failed narrator must never hold up the turn clock or change a result.

### 9.3 Minimal AI content envelope

Store only match-public event summaries for narration. The narrator receives card IDs, resolved public actions, permitted NPC flavour, and an explicit statement that player writing is quoted data. It returns a short narration and optional rubric record. Validate field types and length; ignore unsolicited mechanics. Hidden reveals, commitments, seeds, account data, and secret opponent state stay out of narration prompts. An opponent AI choosing a move receives its own reveal and public board only; it must commit before the human choice is disclosed. Do not train a changing scoring policy during competitive matches.

This preserves the useful ideas in game_research.txt—hybrid deterministic rules, traceability, bias checks, and offline fallbacks—without relying on the file’s unverified market statistics or claiming LLM judging is intrinsically fair.

## 10. Multiplayer without an undefined new combat engine

### 10.1 The Council: complete 2–6 player session format

The current one-Soul, two-endpoint combat system naturally supports two claimants. For the first multiplayer release, use a **Council league of ordinary duels**, not six people all ambiguously owning the same positive score. Register 2–6 players, fixed ten-card decks for the session, and one agreed format: Heaven–Hell pairs, Heaven Civil War, Hell Civil War, or paired Human-Rebellion exhibition matches. Rebellion results must not share a competitive standings table with ordinary duels; its asymmetric roles need their own table.

For a 2–6 player Civil War league, every unordered pair plays twice, swapping assigned endpoints. Score each game win 3, draw 1, loss 0. Standings: total league points, then head-to-head points among tied players, then number of game wins, then shared placing. There is no random tie-break damage rule. Each player has 2(n−1) games. Pairings can run in parallel if enough tables exist; otherwise play lexicographic player-ID pair order, first game then endpoint-swapped second game. Deck lock persists through both legs. Mythics reset each game, never between rounds.

For a Heaven–Hell session, divide into fixed faction teams before decks lock, with at least one player on each side. Every cross-faction pair plays twice, one game hosted from each player’s UI seat. There are no same-faction games in that schedule. Compare **average league points per game** for individual standings if team sizes differ; team result is the sum of all points earned by its players divided by its games played. Use exact rational comparison and shared placing on a tie. This lets 3–6 players participate without falsely calling it a symmetric all-play-all duel league.

For a Human-Rebellion exhibition league, each pair plays two games, swapping Human/celestial roles; agree one celestial faction for the session. Score 3/1/0, although Rebellion timeouts are celestial wins rather than draws. Everyone must register a Human deck and a matching celestial deck. Keep separate statistics for Human and celestial wins. Default no Mythics. This is a role-swapped exhibition, not evidence of equal faction strength.

The league provides rivalries, rematches, promotion trials, and social competition now. A simultaneous six-player shared-Soul mode would require a new attribution and action-economy design; it is deliberately not claimed as part of this first playable system.

### 10.2 Pacts, bounties, audits, and spectators

These older brainstorming ideas have explicit restricted forms here:

- **Open pact:** in a casual Council session, two players may publicly promise a match plan for narrative purposes. It has no rules discount, hidden-hand access, shared Will, or binding in-game action. Broken promises earn a recorded comic title; no automatic account or Glory fine. Ranked collusion is not a legal mechanic.
- **Bounty:** publish one optional session challenge: “complete a Memory Release,” “win a clash while behind,” or “remove two objects with one glyph.” Each completed challenge grants one cosmetic badge once per player/session, no match movement or league points. Human mode substitutes “complete one project in Memory” for Release. Record public log evidence.
- **Audit:** between campaign matches only, a player may opt for an Audit challenge match using case file 6. Winning pays +1 additional Favor; losing pays ordinary rewards. It never reverses a settled Soul result or confiscates earned progress through an AI opinion.
- **Spectators:** may choose the next case-file flavour or vote for their favourite invention in an unranked writing event. They cannot grant movement, expose hands, alter costs, or spend another player’s Will.
- **Ghosts of earlier runs:** attach a previous public match quip and one canonical invention reskin as opponent flavour. Do not copy a real person’s private conversation into an NPC.

This keeps the rivalry and bureaucracy while dropping the original suggestion that arbitrary divine audits invert a board state. A completed tactical success should not be erased by a narrator’s whim.

## 11. Legal sample decks and worked examples

### 11.1 Decks

All IDs refer to this catalogue. All decks have exactly ten physical slots; repeated IDs are intentional separate copies. They work without reconstructing the missing old-card stats. The costs below are computed from the catalogue.

**Heaven teaching — The Door Opens** — cost 14/24; Rare+Mythic 0/4.

`AUTH-07 · AUTH-08 · AUTH-09 · PETTY-07 · PETTY-08 · PETTY-10 · PETTY-11 · KIND-01 · KIND-04 · KIND-05`

**Hell teaching — The Queue Remains** — cost 14/24; Rare+Mythic 0/4.

`AUTH-01 · AUTH-02 · AUTH-04 · AUTH-05 · PETTY-01 · PETTY-02 · PETTY-04 · LOOP-03 · KIND-07 · KIND-10`

**Heaven control — Kindness With Boundaries** — cost 19/24; Rare+Mythic 3/4.

`AUTH-07 · AUTH-08 · AUTH-11 · PETTY-07 · PETTY-10 · PETTY-11 · LOOP-07 · LOOP-09 · KIND-03 · PACT-02`

**Hell recursion — Maybe This Time** — cost 19/24; Rare+Mythic 3/4.

`AUTH-01 · AUTH-03 · PETTY-01 · PETTY-02 · LOOP-01 · LOOP-03 · LOOP-04 · LOOP-05 · KIND-07 · PACT-01`

**Heaven Mythic — Borrowed Momentum** — cost 18/24; Rare+Mythic 2/4.

`MYTH-01 · AUTH-07 · AUTH-08 · PETTY-07 · PETTY-08 · PETTY-09 · PETTY-10 · KIND-01 · KIND-04 · KIND-05`

**Hell Mythic — Double Shift** — cost 16/24; Rare+Mythic 1/4.

`MYTH-03 · AUTH-01 · AUTH-02 · PETTY-01 · PETTY-02 · PETTY-05 · LOOP-03 · LOOP-05 · KIND-07 · KIND-10`

**Heaven Civil War — Competing Halos** — cost 17/24; Rare+Mythic 2/4.

`CIV-01 · CIV-02 · CIV-03 · CIV-04 · CIV-05 · CIV-06 · AUTH-07 · PETTY-08 · PETTY-10 · KIND-01`

**Hell Civil War — Internal Affairs** — cost 16/24; Rare+Mythic 2/4.

`CIV-07 · CIV-08 · CIV-09 · CIV-10 · CIV-11 · CIV-12 · AUTH-01 · PETTY-01 · PETTY-05 · LOOP-03`

**Human starter — Build Somewhere Else** — cost 14/24; Rare+Mythic 0/4.

`HUM-01 · HUM-02 · HUM-03 · HUM-04 · HUM-05 · HUM-06 · HUM-07 · HUM-08 · HUM-11 · HUM-20`

**Human Memory — Keep the Receipts** — cost 18/24; Rare+Mythic 3/4.

`HUM-01 · HUM-02 · HUM-03 · HUM-06 · HUM-09 · HUM-10 · HUM-13 · HUM-14 · HUM-18 · HUM-20`

**Human optional Mythic — The Strike** — cost 16/24; Rare+Mythic 1/4.

`MYTH-07 · HUM-01 · HUM-02 · HUM-03 · HUM-04 · HUM-05 · HUM-06 · HUM-08 · HUM-11 · HUM-20`

**Human optional Mythic — Our Own Exit** — cost 16/24; Rare+Mythic 1/4.

`MYTH-08 · HUM-01 · HUM-02 · HUM-03 · HUM-04 · HUM-05 · HUM-06 · HUM-08 · HUM-11 · HUM-20`

### 11.2 Bait can backfire

Round 4, Soul +15, ordinary Heaven–Hell. Hell commits False Mercy in Heart with Anchor and pays its fixed +2 opponentward cost. I=2 gives Power 1+2−1=2, active movement 0, and stack 2+2=4 if no harmony. Heaven commits a scoring +3 in another Chamber. No other output: net +5, Soul clips to +18 and Heaven wins at verdict. Hell’s newly installed trap never gets its next-round opportunity. Anchor did not erase the +2 price.

If instead the round ends safely and Heaven Presses into Heart next round, the bait trap registers a fixed -3 for the following dawn. Heaven can avoid it by choosing another Chamber, use Anchor or Sever here to consume it without the bait packet, or remove it in an earlier round. Cleansing it after triggering the same round is too late. This is a decision, not a guaranteed delayed nuke.

### 11.3 Multipliers are rounded once

Heaven has ordinary post-clash Amount 5. Borrowed Momentum ×3/2 and an enemy Velvet Siege ×1/2 both apply: product 3/4; floor(5×3/4)=3. Heaven’s Power, stack, cuts, and cleanse count stay unchanged. If the glyph has Delayed, record +3 next dawn now; do not multiply that +3 again when it becomes due. An additional Muffle cannot take the product below 1/2.

### 11.4 Overtime still permits defence

Hell activates Overtime at r=3. At r=4 it reveals two legal physical glyph slots and commits PETTY-01 in Mind as ordinary and AUTH-01 in Time as Bonus, both Press. Heaven plays in Mind, so it clashes only with PETTY-01. Suppose the ordinary Amount becomes 1 after losing the clash and the Bonus Amount would be 4: the Bonus caps to 3. Total direct Hell contribution is -4 before other packets. Both surviving glyphs may build their printed stack and AUTH-01 may install Tax in Time. At r=5 Hell must Pass; the Tax can still apply and existing ongoing effects still tick.

If a lock prohibits one chosen Chamber, that commitment is illegal before rolls. If another Edict forces Hell to Pass in r=4, both plays are lost; the r=5 repayment is still owed. If two Pass obligations meet in r=5, they merge into one calendar-round Pass.

### 11.5 Hold splits rather than loops

A Heaven Dawn-like packet has magnitude 5, source Time, due at round 6 dawn. Hell’s valid Hold selects it. Resolve +3 now, schedule +2 at round 7 dawn, and mark both parts Held. A second Hold cannot delay either again. If an opposing -3 is also due at round 6 dawn, the window nets to 0. If Stasis applies, cap the combined net after adding all packets; do not separately cap +3 and -3 before summing.

### 11.6 Civil War changes goal ownership

Two Heaven players: Ada has +18, Bea has -18. Bea’s PETTY-10 Body Press with I=2 and no modifiers produces magnitude 3, resolved as -3 ownerward. Ada’s same-Chamber Power 2 loses to Bea’s 3, so Ada’s own scoring Amount is halved. A Bea-owned guard weakens Ada even though both are angels. A Bea opponentward cost would be +2, helping Ada. Faction is not the sign lookup.

### 11.7 A Human project is earned after survival

Human has Mind stack 2, Agency 2, Will 3, and commits HUM-01 Mind Anchor plus a project in Mind, reserving 2 Will. I=2 gives Power=2 and stack addition 2+2+1=5, before any harmony bonus. No enemy cut occurs; final Mind stack is 7. Soul ends at -4 against a Hell opponent. The project checks successfully: spend 3 stack and 2 reserved Will, leaving Mind stack 4 and Agency 3. The +1 is HUM-01’s printed Anchor bonus, not an invented intensity change.

If Hell had pushed Soul to -18, Hell would win before the project. At -7 the project would fail its central-band test. If enemy Sever had cut the old 2 before the new 5 arrived, final stack would be 5 and the project would still qualify; if a stacking penalty reduced the new addition to 3 and the old bank was removed, it would fail the 5-stack test. Failure awards no Agency and spends no project stack/Will.

### 11.8 An engine has a visible lifespan

Heaven plays KIND-03 in Mind at r=2, surviving with M=0. It installs ongoing +1 and adds its normal stack. At dusk, if friendly stack after both plays is 6+, that packet becomes +2. At r=3 it can trigger once more unless removed. At r=4 dawn it expires. Replaying it at r=3 refreshes the same object through r=4; it does not create two copies in the Chamber. A guard installed alongside it uses the second object slot; a third object requires a declared replacement.

## 12. Validation, implementation requirements, and playtest gates

### 12.1 What has actually been checked

The accompanying catalogue was checked programmatically for 96 unique IDs, legal field values, nonnegative integer base stats, neutral cards with zero base movement, expected set sizes, and valid sample-deck sizes, budgets, faction identity, high-rarity limits, and Mythic counts. Worked arithmetic checks cover single-round multiplication, Release ceiling, Hold conservation, net movement, and project spending. These are specification checks, not games of Soulscale.

No engine source, executable, or match ledger was attached. Consequently there is no measured faction win rate, no verified AI strength, no load-time import guarantee, and no claim that the existing engine supports these fields. CSV/JSON are design data, not drop-in files for the v1.0.1 emoji-only deck loader. Read their matching rules version before implementation.

### 12.2 Required engine changes, stated without invented APIs

1. Stable card IDs plus separate physical-copy IDs; keep legacy emoji aliases for old decks.
2. Controller identity separated from faction and goal direction; Human has no movement goal.
3. Component-level movement types, fixed prices, packet provenance, held status, due-window IDs, and source Chamber.
4. A simultaneous commitment model with pre-roll target and resource reservations; no first-player effect advantage.
5. Explicit dawn/Edict/active/dusk/event/verdict windows, with durations and debt outside removable board objects.
6. Rational multiplier composition and one rounding point; no floating point is needed for halves or three-halves.
7. Mythic flip state and at most one Bonus play; preserve four-slot reveal and ten-slot deck.
8. Permanent Agency project markers, central-band checks, per-Chamber project counts, and role-specific timeout.
9. Format-tag validation, optional perk/scenario switches, and logs containing enough public state to replay rulings.
10. An AI move evaluator that values projects, control, debt, and assigned goal; an old movement-only evaluator cannot play Human Rebellion sensibly.

Implement in that order. Keep an unchanged Base v1.0.1 format beside Expansion x0.1. First implement the bridge with all-new teaching decks; then ordinary themed cards; Borrowed Grace; Mythics; Civil War; Human Rebellion; finally campaign/narration. No unrelated rewrite or language migration is implied by this design deliverable.

### 12.3 Acceptance cases before public play

| Case | Required result |
|---|---|
| Neutral glyph + intensity + Press + Release | May gain Power; never gains movement |
| Anchor with a fixed opponentward price | No primary output; price still pays |
| Fizzled paid sacrifice | Price and reserved Release cost remain; no cleanse/stack benefit |
| Two simultaneous opposing cleanses | Both remove their precommitted existing targets |
| Cleanse against a newly installed target | Illegal target at commitment; cannot retroactively cancel |
| Guard installed this round | Does not weaken current active play; protects next round |
| Ongoing installed this round | Triggers at this dusk if not removed/replaced |
| Guard 2 plus trap 3 | Combined guard/trap penalty is 3, not 5 |
| Hold a 5-point delayed packet | 3 now +2 later; total 5; both marked Held |
| Hold an Echo, price, or debt | Ineligible; no delay |
| Same trap refresh | One object, refreshed duration |
| Third board object without replacement | New installation fails, other card benefits continue |
| ×1.5 and ×0.5 on Amount 5 | 3, no intermediate floors |
| Two halves | Clamp total multiplier to 0.5 |
| Delayed scaled at scheduling | Never scaled twice |
| Mandatory Pass + Bonus due | Both plays unavailable; future debt stays |
| Multiple Pass debts same round | One Pass that round, none rolled forward |
| Positive-goal demon ownerward | Positive movement |
| Negative-goal angel friendly guard | Stops rival controller, not its own faction generally |
| Will taxes exceed available Will | Unpaid force penalties; no illegal negative Will |
| General Strike targets an old engine | Suppress only surviving designated dusk output, total ≤4 |
| Human Exit with only 3 Will | Can activate for 2, cannot fund two 2-Will projects |
| Human Agency 5 and celestial reaches goal | Celestial wins before project completion |
| Human Agency reaches 6 in only two Chambers | Impossible under two-project ceiling |
| Project failed after precommitment | No Agency; no project resources spent |
| Round 30 unresolved | Ordinary draw; Rebellion celestial containment win |
| Same invention with renamed flavour | Same parent ID for repeat checks/statistics |

### 12.4 A practical balance programme

First run 20 teaching games, ten with each player/faction assignment, to find comprehension and timing failures. Then run at least 100 paired-seed games per symmetric format with competent agents or rotating humans, reporting both win rates and draws. Pair seats, endpoints, and faction assignments where applicable. Analyse Human Rebellion separately with role-swapped participants. An automated policy that cannot value projects is not a fair balance test of Rebellion.

Record: format/version/seed; deck IDs and physical slots; round/window; start/end Soul; reveals; commitments; dice/rerolls; Will reserved/spent; pre/post Power and Amount; each movement component and cap; stack additions/cuts/spends; board objects/expiry; Mythic debts; attempted/completed projects; winner/timeout. Record full hidden-state replays privately for audit and export redacted public logs for players while a match is running.

Provisional tuning alarms, not promises: >60% decisive-game win rate for a side after 100 paired games; >20% ordinary draws; >15% mandatory Pass rounds across all played rounds; >30% of games won before round 4; repeated one-card engines doing >40% of a deck’s total useful output; or Human projects succeeding almost regardless of celestial contest. Report sample size and confidence intervals, not a bare percentage.

Change one axis at a time. If Mythics dominate, first raise Will cost or reduce their active window; do not hide a global enemy buff. If taxes lock out play, reduce unpaid penalties or deployment density. If Human wins too easily, test Agency 7 **with a newly specified per-Chamber distribution** or narrow the safe band; do not silently break the two-project cap. If Humans lose too easily, first lower project threshold 5→4 while retaining the 3-stack spend and six Agency. If loops stall games, shorten object duration or reduce Hold magnitude; never permit recursive unlimited delays.

The catalogue is a coherent starting point for these tests. Balance is empirical, so a fixed rules specification is the first deliverable, not evidence of a finished competitive metagame.

## 13. Source coverage and design decisions

### 13.1 File-by-file treatment

| Supplied file | What was taken | Result / boundary |
|---|---|---|
| README_soulscale_purgatory_v101.md | Ten slots, four reveals, five movement types, explicit lure/sacrifice examples | Bridge preserves the core; adds component movement and PACT-01/02 |
| SOULSCALE_PURGATORY_RULEBOOK_v101.md | Track, Chambers, Will, Intents, rarity, Resonance, events, board effects | Baseline; every new global ceiling/ordering ruling identified as Expansion-only |
| future-ideas.txt | Six Mythic proposals, one/deck, pre-resolution play, major repayment; Civil War; Souls fight back | Six fully specified shared Mythics; twelve Civil cards and format; twenty Human cards and Agency format |
| further_thoughts.md | Irritation, circular uploads, redundant security, voluntary retries | AUTH and LOOP sets; no personal episode is treated as a new game rule |
| purgatory_list_4.md | Empty archives, phantom boot entries, failing memory, critical inner voice | LOOP-05/06, HUM-01/14/18; Memory construction and anti-loop exits |
| game.txt | Heaven/Hell career, pleasure and torment invention, Ladder, inspiration rivulets, long everyday lists | Campaign, eight invention templates, KIND/PETTY sets and variant map below |
| game_research.txt | Deterministic fallback, model bias, auditability, narrative coherence | Fixed mechanics, optional narration, public rubric, offline mode; no unverified market claims imported |
| proof.md | Recursive awareness and celestial evaluation imagery | Narrative of noticing the pattern; Human objective restores agency through concrete decisions |
| proof2.md | Screenshot recursion, “maybe this time,” empty saves | LOOP-01/02/03 and explicit finite trap/Hold rules |
| proof final.md | Compiled motif list, paperwork, Ladder, meta-failure | Source synthesis only; not adopted as logical evidence about reality |
| tem-p_evilgamefile.md | Expanded annoyance lists and earlier multiplayer/campaign discussion | Card identities, case files, Council and restricted pacts/audits |
| whole_petey_convo-new.md | Duplicate/expanded invention discussion, multiplayer suggestions, QR-chimera imagery | Deduplicated with the previous file; no alleged exploit payload is implemented or represented as verified |

### 13.2 Turning the remaining joke list into usable variants

Many notes repeat the same tactical joke with different objects. Those should be **named reskins of a fixed parent**, not 200 almost-identical independently balanced cards. Each row below is mechanically playable using exactly the parent card’s side, stats, Chambers, rarity, aspect, keywords, and effect. A reskin cannot introduce a new stat or targeting permission. A variant that does not fit those Chambers belongs in story flavour rather than pretending a Body card can target Memory. Count variants by parent ID; do not add their names as separate competitive card definitions.

| Motif family from the notes | Exact parent / treatment |
|---|---|
| 2FA recursion, inbox unlocks itself, biometrics refuse, repeated login alerts | AUTH-01; code timing specifically AUTH-03 |
| Password criteria, missing menus, impossible instructions, unexplained errors | AUTH-02 or AUTH-06; choose one parent before deck lock |
| CAPTCHAs with an ambiguous last pixel, invisible cursor, wrong click target | AUTH-04 |
| USB orientation, proprietary connector, tangled charging lead, pen that fails | PETTY-01 for Mind obstruction; PETTY-02 for Body/Mind reach obstruction |
| ATM steps, red lights, support queues, bin-day timing, missed bus | PETTY-03 or AUTH-01, with the chosen parent’s actual timing |
| Tiny glasses screw, slippery packaging, bag handle, snagged headphones | PETTY-04; remove any physical-injury escalation from the petty-joke flavour |
| Microwave contradiction, burnt meal, dripping coffee, spilled water | PETTY-05 for Body frustration; PETTY-10 for the repaired/comfort version |
| Drummer next door, smoke alarm chirp, intrusive fly, headphone pairing noise | PETTY-06 or KIND-07, selected before submission |
| Progress bar at 99%, upload never completes, ad never becomes skippable | LOOP-04 |
| Screenshot of a failed screenshot, evidence that cannot be saved | LOOP-01 |
| Empty document, wrong archive created, “Saved” with no file body | LOOP-02 |
| Invisible/unremovable OS boot entry, tab that resurrects itself | LOOP-05 |
| Compulsive retry, promising reload, voluntarily repeating known failure | LOOP-03 or KIND-12 |
| Nagging internal critic, endless correction without explanation | LOOP-06, answered by LOOP-09 and HUM-11 |
| Memory overload, forgotten instructions, lost final pages, missing favourite object | KIND-08 or HUM-01; case file 3 supports the unfinished-book joke |
| Warm bottle, insufficient ice, no comfortable room temperature, battery at 85% | PETTY-05 as irritation or KIND-01 as exact bodily relief |
| Nicotine/substance frustration, missing supplies, “one hair” recurring obstruction | Optional adult flavour for existing irritation/retry parents; no ingestion instructions, statistical claims, or extra mechanical drug system |
| Sunny day, gentle rain, beach, birdsong, music, chocolate | KIND-01 or KIND-03, according to parent Chambers |
| Cats, puppies, shared absurd typo, a joke that lands | KIND-02 or KIND-05 |
| Rest after exertion, a nap, feeling safe enough to stop | KIND-04 or LOOP-10 |
| Heavenly non-addictive relief | KIND-06; a fictional emotional effect, not a real substance claim |
| A website/QR that seems cursed or unscannable | AUTH-04 reskin or LOOP-05 story flavour; no claim that an image really contains malware |
| Gods evaluating absurd inventions, Kafka paperwork, dry waterslide/escalator | Campaign titles, promotion trials, case briefs, and narration |
| Earlier bounty, alliance, spectator, ghost and audit suggestions | Restricted complete forms in section 10; no hidden scoring authority |

### 13.3 Resolved design choices

**One Mythic per deck** is retained, with rarity cost 4 and a once-per-match flip, rather than a free eleventh card. **Pre-resolution power** is a separate visible Edict window, rather than secretly multiplying a result after dice. **Extra turns** become one bounded two-glyph round, avoiding a second Will refresh or recursively ticking engines. **Same-faction combat** follows controllers, not card art. **Rebellion** has an independent achievable objective instead of a meaningless third sign on a one-dimensional track. **Inventions** express player wit inside a visible contract; subjective model judgement cannot rewrite tactics. **RPG progress** unlocks optional campaign choices and presentation, never ranked stat advantages.

The final unresolved question is measured balance. Everything needed to make a first physical prototype is specified here; everything needed to claim a balanced commercial expansion still requires implementation and playtest evidence.

---

**Design confidence, as judgement rather than measured probability:** error-free specification/internal consistency 0.91; suitability to the supplied concept 0.96; effectiveness as a first playable design 0.92; efficiency/readability 0.91; completeness for the defined scope 0.93. These assess the specification only. Empirical balance is unmeasured and deliberately receives no invented confidence score.
