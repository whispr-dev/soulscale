# Soulscale expansion design pack x0.1

Start with SOULSCALE_EXPANSION_DESIGN_BIBLE_x01.html for a readable, printable edition. The Markdown edition is the editable source text. This is a proposed first playable expansion, not a game update.

Included:
- Full design bible: rule bridge, 96 cards, eight sets, Mythics, Civil War, Human Rebellion, campaign/inventions, Council session format, sample decks, worked examples, source coverage, and playtest acceptance cases.
- Catalogue JSON and UTF-8 CSV: every card's base stats and complete printed effect. These are design records, not an existing-engine import schema. Refer to the bible for all timing and format rules.
- Sample decks JSON: twelve validated ten-slot decks with cost totals.
- Specification checks JSON: counts, deck checks, and bounded arithmetic verification; no empirical win-rate claim.

No software installation is needed to read or print this pack. Open the HTML in any current browser; use Print / Save as PDF if desired. Physical play needs the original track and Chambers, a d6 per player, counters, and these card records. Begin with the two teaching decks and no Mythics.

Version boundary: original v1.0.1 remains unchanged. Expansion x0.1 changes timing, ceilings, controller semantics, and adds packet-level movement. None of this has been implemented or tested against the Python app, which was not attached. Balance must be playtested.
